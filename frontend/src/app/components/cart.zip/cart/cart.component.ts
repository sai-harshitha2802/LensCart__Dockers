// import { Component, OnInit } from '@angular/core';
// import { CartService } from 'src/app/services/cart.service';
// import { AuthService } from 'src/app/services/auth.service';
// import { Router } from '@angular/router';

// @Component({
//   selector: 'app-cart',
//   templateUrl: './cart.component.html',
//   styleUrls: ['./cart.component.css'],
// })
// export class CartComponent implements OnInit {
//   cart: any = {};
//   customerId: number | null = null;

//   constructor(
//     private cartService: CartService,
//     private authService: AuthService,
//     private router: Router
//   ) {}

//   ngOnInit(): void {
//     this.customerId = this.authService.getLoggedInUserId();
//     if (!this.customerId) {
//       this.router.navigate(['/login']);
//       return;
//     }

//     this.cartService.getCart(this.customerId).subscribe(
//       (data) => {
//         this.cart = data;
//       },
//       (error) => {
//         console.error('Error fetching cart data', error);
//       }
//     );
//   }

//   // Function to remove an item from the cart

//   // Function to proceed to checkout
//   proceedToCheckout(): void {
//     this.router.navigate(['/checkout']);
//   }
// }
import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/services/cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  cart: any = {};
  customerId: number | null = null;

  constructor(private cartService: CartService, private router: Router) { }

  // ngOnInit(): void {
  //   const idFromStorage = localStorage.getItem("customerId");
  //   this.customerId = idFromStorage ? Number(idFromStorage) : null;

  //   if (!this.customerId) {
  //     this.router.navigate(['/login']);
  //     return;
  //   }

  //   this.cartService.getCart(this.customerId).subscribe(
  //     (data) => {
  //       this.cart = data;
  //     },
  //     (error) => {
  //       console.error('Error fetching cart data', error);
  //     }
  //   );
  // }
  ngOnInit(): void {
    const idFromStorage = localStorage.getItem("customerId");
    this.customerId = idFromStorage ? Number(idFromStorage) : null;

    if (!this.customerId) {
      this.router.navigate(['/login']);
      return;
    }

    // ✅ Add this log here
    console.log('Fetching cart for customerId:', this.customerId);

    // this.cartService.getCart(this.customerId).subscribe(
    //   (data) => {
    //     console.log('Cart data received:', data); // Optional: log the response too
    //     if (!data || !data.productId) {
    //       this.cart = { products: [], totalAmount: 0 };
    //       return;
    //     }

    //     const productNames = data.productId.split(','); // Example: "FRAME-1,FRAME-1"
    //     const pricePerItem = data.productPrice || 0;
    //     const quantity = data.quantity || 0;

    //     // Construct one item per product name (like quantity = 1 for each)
    //     const products = productNames.map((productName: string) => ({
    //       productName,
    //       price: pricePerItem,
    //       quantity: 1,
    //     }));

    //     this.cart = {
    //       products,
    //       totalAmount: pricePerItem * quantity,
    //     };
    //   },
    //   (error) => {
    //     console.error('Error fetching cart data', error);
    //     this.cart = { products: [], totalAmount: 0 };
    //   }
    // );

    this.cartService.getCart(this.customerId).subscribe(
      (data) => {
        console.log('Cart data received:', data);

        if (!data || !data.cartItems || data.cartItems.length === 0) {
          this.cart = { products: [], totalAmount: 0 };
          return;
        }

        const products = data.cartItems.map((item: any) => ({
          productName: item.productId,
          price: item.price,
          quantity: item.quantity,
        }));

        this.cart = {
          products,
          totalAmount: data.totalAmount || 0,
        };
      },
      (error) => {
        console.error('Error fetching cart data', error);
        this.cart = { products: [], totalAmount: 0 };
      }
    );





  }

  // removeFromCart(productId: string): void {
  //   const customerId = Number(localStorage.getItem("customerId"));
  //   if (!customerId) return;

  //   this.cartService.removeProduct(customerId, productId).subscribe(
  //     (response) => {
  //       console.log('Product removed:', response);
  //       this.cart = response; // Update cart in UI
  //     },
  //     (error) => {
  //       console.error('Error removing product:', error);

  //     }
  //   );
  // }

  removeFromCart(productId: string): void {
    if (!this.customerId) return;

    this.cartService.removeProduct(this.customerId, productId).subscribe(
      (response) => {
        console.log('Product removed:', response);

        if (!response || !response.cartItems || response.cartItems.length === 0) {
          this.cart = { products: [], totalAmount: 0 };
          return;
        }

        const products = response.cartItems.map((item: any) => ({
          productName: item.productId,
          price: item.price,
          quantity: item.quantity,
        }));

        this.cart = {
          products,
          totalAmount: response.totalAmount || 0,
        };
      },
      (error) => {
        console.error('Error removing product:', error);
      }
    );
  }

  changeQuantity(productId: string, newQuantity: number): void {
    if (!this.customerId || newQuantity < 1) return;

    this.cartService.updateQuantity(this.customerId, productId, newQuantity).subscribe(
      (updatedCart) => {
        const products = updatedCart.cartItems.map((item: any) => ({
          productName: item.productId,
          price: item.price,
          quantity: item.quantity,
        }));

        this.cart = {
          products,
          totalAmount: updatedCart.totalAmount || 0,
        };
      },
      (error) => {
        console.error('Error updating quantity:', error);
      }
    );
  }




  proceedToCheckout(): void {
    this.router.navigate(['/checkout']);
  }
}
